# Thaos Bestiary Canon (Current)

## Velorian Prime
- Inkfeather Drakes
- Archivore Beetles
- Dustglass Ibex
- Glyphweaver Spiders
- Suneater Falcons
- Cerulean Dune-Foxes
- Stone-Skink Runners
- Quillback Tortoises
- Scriptbound Hounds
- Inkling Wisps
- Glyph Serpents
- Mnemonic Bats
- Vellum-wings
- Obsidian Moths
- Lorewyrms

## Coggendra
- Copperback Jackals
- Cogmice
- Holo-Owls
- Striped Flitterbats
- Pulse Rats
- Wirebeaks
- Glass-Pelt Weasels
- Hingehounds
- Memory Sprites
- Neuro-Foxes
- Synapse Eels
- Identity Gnats
- Echo Cats
- Mind-Weavers
- Circuit Serpents

## Aereth Hallow
- Cliffspan Goats
- Windrazor Kites
- Hallow Crag-Wolves
- Crested Rockhares
- Vellwing Swifts
- Mossback Ibisa
- Shale Beetles
- Aereth Sandmartens
- Harmonic Owls
- Chorallion Frogs
- Resonance Lynxes
- Skywhorl Gliders
- Chordscale Serpents
- Echo-Mites
- Verse-Mares

## Thaelwood Ascent
- Trunkback Elk
- Rootclaw Bears
- Fleetridge Squirrels
- Grove Owls
- Mottle Froghoppers
- Tallbranch Monks
- Pollen Hounds
- Bloom-Foxes
- Verdant Constructs
- Lantern Wasps
- Sap-Lurkers
- Whisper Ferns
- Barkscale Lizards
- Leyline Beetles
- Thornspire Serpents

## Blackfruit Haven
- Duskapes
- Shadow Voles
- Nightglass Serpents
- Glowspore Bats
- Hollow-Maws
- Veil Panthers
- Root-Treader Boars
- Blackfruit Starlings
- Eventide Hares
- Gloom Owls
- Umbral Frogs
- Lumenmoths
- Shade Basilisks
- Inkcap Ravens
- Dusk Vipers

## Stargrave Expanse
- Meteor Hares
- Starglass Coyotes
- Skycarp
- Dust Crawler Tortoises
- Crested Wanderers
- Sand Comet Beetles
- Chromatic Ibex
- Void Crabs
- Starborn Eels
- Cosmic Lanternbugs
- Astral Moths
- Meteor Wyrmlings
- Solar Serpents
- Stellar Foxes
- Riftglider Skates

## Tideglass Archipelago
- Tideglass Gulls
- Opalback Turtles
- Reed Otters
- Aqua-Prowlers
- Surf-Treader Crabs
- Crystal Minnows
- Kelp-Wolf Eels
- Wavekestrels
- Siren Sprites
- Glassfin Sharks
- Mist-Mantles
- Coralbound Rays
- Tide-Run Serpents
- Pearl Bloomers
- Soundcurrent Dolphins

## Titanfall Range
- Stonecrest Eagles
- Ironclaw Bears
- Mason Ibex
- Highridge Lynxes
- Shattertooth Boars
- Thunder Hares
- Frostline Wolves
- Talon Moles
- Titanbone Wyrmlings
- Storm-Forged Rams
- Shardwing Griffins
- Rumblewyrms
- Skylance Hawks
- Stonecoil Pythons
- Golem Stags
