# Systems Index

Document magic systems, technology, government, economy rules, and other systemic elements here.
