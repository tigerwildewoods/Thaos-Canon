# Energetics
