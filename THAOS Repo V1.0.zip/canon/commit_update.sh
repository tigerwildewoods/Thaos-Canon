#!/bin/bash
# commit_update.sh - simplistic local versioning helper
# Usage: ./commit_update.sh [sections=comma,separated]

REPO_ROOT="$(cd "$(dirname "$0")/.."; pwd)"
VERSION_FILE="$REPO_ROOT/canon/VERSION.txt"
if [ -f "$VERSION_FILE" ]; then
  ver=$(cat "$VERSION_FILE")
else
  ver="1.0"
fi
IFS='.' read -r major minor <<< "$ver"
SECTIONS=$1
# If sections provided, count them, else default to 'auto' (not implemented in script)
if [ -z "$SECTIONS" ]; then
  echo "Auto-detection not implemented in this helper. Please provide sections."
  echo "Example: ./commit_update.sh regions"
  exit 1
fi
count=$(echo "$SECTIONS" | sed 's/,/ /g' | wc -w)
if [ "$count" -gt 1 ]; then
  major=$((major+1))
  minor=0
else
  minor=$((minor+1))
fi
newver="${major}.${minor}"
echo "$newver" > "$VERSION_FILE"
zip -r "$REPO_ROOT/../THAOS Repo V${newver}.zip" "$REPO_ROOT"
echo "Created THAOS Repo V${newver}.zip"
