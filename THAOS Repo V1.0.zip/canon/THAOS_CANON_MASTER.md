# THAOS Canon Master (v1.0)
This repository is an aggregated merge of user-uploaded THAOS archives.
Version: 1.0
Merged sources:
[
  "thaos-bestiary-main.zip",
  "THAOS_CANON_v0.2_mythic.json.zip",
  "thaos_bestiary_canon.zip",
  "THAOS_PHASE3_structures.zip",
  "THAOS_PHASE3_full_expanded.zip",
  "THAOS_CANON_v0.1.zip",
  "THAOS_CANON_v0.1_merged.zip",
  "THAOS_PHASE1_resonance.zip",
  "THAOS_PHASE2_ecospheric.zip",
  "THAOS_Canon.zip",
  "THAOS_CANON_v0.3_full_depth.zip",
  "THAOS-main.zip",
  "THAOS_Myth_Cycle_Sigils_FULL.zip",
  "THAOS_Myth_Cycle_Sigils.zip",
  "THAOS_Myth_Cycle_Sigils"
]
---

## Summary
- Regions folder: 6 files
- Creatures folder: 15 files
- Myth cycles: 5 files
- Sigils: 85 files
- Structures: 14 files
- Resonance: 0 files
