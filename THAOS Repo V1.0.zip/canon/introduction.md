# Introduction

This is the high-level introduction to the THAOS setting.

**Suggested sections to fill:**
- World concept & tone
- Major themes
- Short logline / elevator pitch
- How to read this wiki
