# Contributing

Guidelines for contributing to the THAOS Wiki.

- How to propose edits (pull requests)
- File naming conventions
- Frontmatter / metadata (optional)
- How to add a character/location entry
