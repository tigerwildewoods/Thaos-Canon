# Locations Index

- **City / Region** — short blurb  
- Add maps and images to `assets/maps/` and reference them here.
