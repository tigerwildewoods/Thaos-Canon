# CHANGELOG

## v1.0 - Initial merge

Merged archives:
- thaos-bestiary-main.zip
- THAOS_CANON_v0.2_mythic.json.zip
- thaos_bestiary_canon.zip
- THAOS_PHASE3_structures.zip
- THAOS_PHASE3_full_expanded.zip
- THAOS_CANON_v0.1.zip
- THAOS_CANON_v0.1_merged.zip
- THAOS_PHASE1_resonance.zip
- THAOS_PHASE2_ecospheric.zip
- THAOS_Canon.zip
- THAOS_CANON_v0.3_full_depth.zip
- THAOS-main.zip
- THAOS_Myth_Cycle_Sigils_FULL.zip
- THAOS_Myth_Cycle_Sigils.zip
- THAOS_Myth_Cycle_Sigils
