# workflow_update_repo - Spec
# This workflow compares canonical folders and increments version according to rules:
# - If changes affect only one content section -> X.Y -> X.(Y+1)
# - If changes affect multiple sections -> X.Y -> (X+1).0
# Sections: regions, creatures, myth_cycles, sigils, structures, resonance, canon
#
# Usage:
#   ./commit_update.sh [sections]
# If sections are provided, they are used to determine the bump; otherwise auto-detects.
