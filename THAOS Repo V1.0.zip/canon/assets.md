# Assets

Place images, maps, and concept art in the `assets/` folder. Reference them in markdown:

```
![](assets/images/example.png)
```
