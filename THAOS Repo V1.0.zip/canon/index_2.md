# Characters Index

- **Character Name** — short blurb  
- Use individual markdown files for major characters (e.g., `docs/characters/john-doe.md`)
